# Cài / gỡ bản Việt hóa Hi-Fi RUSH.  Dùng:  install.ps1            (cài)
#                                          install.ps1 -Uninstall (gỡ)
#                                          install.ps1 -GameDir "D:\...\Hi-Fi RUSH"  (chỉ định thư mục game)
param([string]$GameDir = "", [switch]$Uninstall)
$ErrorActionPreference = "Stop"
$PakName = "Hibiki-WindowsNoEditor_9999_P.pak"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

function Find-Game {
    $cands = @()
    $steam = $null
    foreach ($k in "HKCU:\Software\Valve\Steam", "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam") {
        try { $v = (Get-ItemProperty $k -ErrorAction Stop); $steam = $v.SteamPath; if (-not $steam) { $steam = $v.InstallPath }; if ($steam) { break } } catch {}
    }
    if ($steam) {
        $steam = $steam -replace "/", "\"
        $cands += Join-Path $steam "steamapps\common\Hi-Fi RUSH"
        $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            Select-String -Path $vdf -Pattern '"path"\s+"([^"]+)"' | ForEach-Object {
                $p = $_.Matches[0].Groups[1].Value -replace "\\\\", "\"
                $cands += Join-Path $p "steamapps\common\Hi-Fi RUSH"
            }
        }
    }
    foreach ($d in "C", "D", "E", "F", "G") { $cands += "${d}:\SteamLibrary\steamapps\common\Hi-Fi RUSH"; $cands += "${d}:\Program Files (x86)\Steam\steamapps\common\Hi-Fi RUSH"; $cands += "${d}:\XboxGames\Hi-Fi RUSH\Content" }
    foreach ($c in $cands) { if ($c -and (Test-Path (Join-Path $c "Hibiki\Content\Paks"))) { return $c } }
    return $null
}

if (-not $GameDir) { $GameDir = Find-Game }
if (-not $GameDir -or -not (Test-Path (Join-Path $GameDir "Hibiki\Content\Paks"))) {
    Write-Host "Không tìm thấy thư mục game. Chạy lại với: install.ps1 -GameDir `"D:\...\Hi-Fi RUSH`"" -ForegroundColor Red
    exit 1
}
$PaksDir = Join-Path $GameDir "Hibiki\Content\Paks"
$Target = Join-Path $PaksDir $PakName
Write-Host "Thư mục game: $GameDir"

if ($Uninstall) {
    if (Test-Path $Target) { Remove-Item $Target -Force; Write-Host "Đã gỡ bản Việt hóa." -ForegroundColor Green }
    else { Write-Host "Chưa cài bản Việt hóa." }
    exit 0
}

$Src = Join-Path $Here $PakName
if (-not (Test-Path $Src)) { Write-Host "Thiếu file $PakName cạnh install.ps1" -ForegroundColor Red; exit 1 }
if (Get-Process "Hi-Fi-RUSH*" -ErrorAction SilentlyContinue) { Write-Host "Hãy tắt game trước khi cài." -ForegroundColor Yellow; exit 1 }
Copy-Item $Src $Target -Force
Write-Host "Đã cài: $Target" -ForegroundColor Green
Write-Host "Việc còn lại: Steam > chuột phải game > Properties > Launch Options > gõ  -fileopenlog"
Write-Host "Vào game chọn ngôn ngữ English (bản Việt hóa thay thế tiếng Anh)."
Write-Host "Lưu ý: cách này chỉ có chữ; font gốc thiếu 92 chữ có dấu, xem HUONG_DAN.md (Cách 1) để có font."
